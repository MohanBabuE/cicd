// Basic test setup for CI/CD pipeline

// This file can be used to set up global test configurations
// Add any setup code needed for tests here